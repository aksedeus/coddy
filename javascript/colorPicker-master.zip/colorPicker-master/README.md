# color picker
https://worst-in-me.github.io/colorPicker/dist/ - результат
