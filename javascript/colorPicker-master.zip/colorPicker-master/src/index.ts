import { createColorPicker } from './colorPicker.js';

const colorPicker = createColorPicker();
// colorPicker.style.cssText = 'transform: scaleY(0.3)';

document.body.appendChild(colorPicker);
